/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai1;

/**
 *
 * @author T
 */
public class Diem {
    private double value;

    public Diem() {
    }

    public Diem(double value) {
        this.value = value;
    }

    public double getValue() {
        return value;
    }
    
}
