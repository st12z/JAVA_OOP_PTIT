/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai1;

/**
 *
 * @author T
 */
public class Matrix{
    private int hang,cot;
    private int a[][];

    public Matrix() {
        a=new int[hang][cot];
    }
    
    public Matrix(int hang, int cot, int[][] a) {
        this.hang = hang;
        this.cot = cot;
        this.a = a;
    }

    @Override
    public String toString() {
        String res="";
        for(int i=0;i<hang;i++){
            for(int j=0;j<cot;j++){
                res+=a[i][j]+" ";
            }
            res+="\n";
        }
        return res;
    }
    
}
